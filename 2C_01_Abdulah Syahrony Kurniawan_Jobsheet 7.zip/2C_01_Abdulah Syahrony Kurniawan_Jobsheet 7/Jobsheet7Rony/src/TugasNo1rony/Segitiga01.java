/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TugasNo1rony;

/**
 *
 * @author LENOVO
 */
public class Segitiga01 {
    private int sudut;
    
    public void setSudut(int sudut) {
        this.sudut = sudut;
    }
    
    public int totalSudut(int sudutA){
        return sudut = 180 - sudutA;
    }
    
    public int totalSudut(int sudutA, int sudutB){
        return sudut = 180 - (sudutA +sudutB);
    }
    
    public int keliing(int sisiA, int sisiB, int sisiC){
        return sisiA + sisiB + sisiC;
    }
    
    public double keliing(int sisiA, int sisiB){
        double c = Math.sqrt(Math.pow(sisiA, 2) + Math.pow(sisiB, 2));
        return c;
    }
}
