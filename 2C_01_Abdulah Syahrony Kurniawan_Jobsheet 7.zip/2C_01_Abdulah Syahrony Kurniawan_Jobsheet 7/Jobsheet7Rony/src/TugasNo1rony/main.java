/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TugasNo1rony;

/**
 *
 * @author LENOVO
 */
public class main {
    public static void main(String[]args){
        Segitiga01 s = new Segitiga01();
        System.out.println("Total Sudut : "+ s.totalSudut(90));
        System.out.println("Total Sudut : "+ s.totalSudut(60, 90));
        System.out.println("Sisi C : "+ s.keliing(3, 4));
        System.out.println("Keliling : "+ s.keliing(4, 6, 8));
    }
}
