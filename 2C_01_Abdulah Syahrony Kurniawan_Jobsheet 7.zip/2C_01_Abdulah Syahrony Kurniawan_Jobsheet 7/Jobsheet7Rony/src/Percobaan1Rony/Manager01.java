/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Percobaan1Rony;

/**
 *
 * @author LENOVO
 */
public class Manager01 extends Karyawan01{
    private double tunjangan;
    private String bagian;
    private Staff01 st[];

    public void setTunjangan(double tunjangan) {
        this.tunjangan = tunjangan;
    }

    public void setBagian(String bagian) {
        this.bagian = bagian;
    }

    public void setStaff(Staff01[] st) {
        this.st = st;
    }

    public double getTunjangan() {
        return tunjangan;
    }

    public String getBagian() {
        return bagian;
    }

    public Staff01[] getSt() {
        return st;
    }
    
    public void viewStaff(){
        int i;
        System.out.println("-----------------------");
        for (i = 0; i < st.length; i++) {
            st[i].lihatInfo();
        }
        System.out.println("-----------------------");
    }
    
    public void lihatInfo(){
        System.out.println("Manager :"+this.getBagian());
        System.out.println("NIP :"+super.getNip());
        System.out.println("Nama :"+super.getNama());
        System.out.println("Golongan :"+super.getGolongan());
        System.out.printf("Tunjangan :%.0f\n", this.getTunjangan());
        System.out.printf("Gaji :%.0f\n",super.getGaji());
        System.out.println("Bagian :"+this.getBagian());
        this.viewStaff();
    }
    @Override
    public double getGaji(){
        return super.getGaji()+tunjangan;
    }
}
