/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TugasNo2rony;

/**
 *
 * @author LENOVO
 */
public class Main01 {
    public static void main(String[]args){
        Manusia01 m = new Manusia01();
        Dosen01 dsn = new Dosen01();
        Mahasiswa01 mhs = new Mahasiswa01();
        
        m.bernafas();
        m.makan();
        System.out.println(" ");
        dsn.makan();
        dsn.lembur();
        System.out.println(" ");
        mhs.makan();
        mhs.tidur();
    }
}
