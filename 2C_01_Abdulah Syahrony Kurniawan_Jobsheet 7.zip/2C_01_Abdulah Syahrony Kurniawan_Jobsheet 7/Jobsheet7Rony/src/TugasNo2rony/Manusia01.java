/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TugasNo2rony;

/**
 *
 * @author LENOVO
 */
public class Manusia01 {
    void bernafas() {
        System.out.println("Manusia memiliki paru paru agar bisa bernafas");
    }
    
    void makan() {
        System.out.println("Manusia juga butuh makan");
    }
}
