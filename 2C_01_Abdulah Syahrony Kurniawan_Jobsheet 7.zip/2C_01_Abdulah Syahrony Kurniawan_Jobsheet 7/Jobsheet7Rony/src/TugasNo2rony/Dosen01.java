/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TugasNo2rony;

/**
 *
 * @author LENOVO
 */
public class Dosen01 extends Manusia01{
    void makan() {
        System.out.println("Dosen butuh makan agar semangat melakukan kewajiban");
    }
    
    void lembur() {
        System.out.println("Dosen lembur ketika tugasnya belum selesai");
    }
}
