/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TugasNo2rony;

/**
 *
 * @author LENOVO
 */
public class Mahasiswa01 extends Manusia01{
    void makan() {
        System.out.println("Mahasiswa mengerjakan tugas juga butuh makan");
    }
    
    void tidur() {
        System.out.println("Mahasiswa juga butuh waktu untuk tidur, tolong deadline diperpanjang");
    }
}
